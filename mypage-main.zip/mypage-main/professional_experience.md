## Positions

* **Lecturer in Statistics**, School of Mathematics and Statistics, University of St Andrews <br/>
Aug 2024 - Present

* **Group Leader** and **Associate Faculty** of the Vienna Graduate School of Population Genetics <br/>
Institute of Population Genetics, Vetmeduni Vienna, Austria <br/>
Jun 2021 - Jul 2024

* **Postdoctoral researcher**, Institute of Population Genetics, Vetmeduni Vienna, Austria <br/>
Jul 2017 - Present <br/>
**Advisors**: Carolin Kosiol and Gergely Szöllősi and Asger Holbolt <br/>
**Project**: Genome-wide molecular dating

* **Bioinformatician**, CIIMAR, University of Porto, Portugal <br/>
Jan 2011 - Jan 2012 <br/>
 **Advisor**: Agostinho Antunes<br/>
**Project**: Phenogenetic drift in evolution <br/>


## Services

*	Reviewer: Systematic Biology, Molecular Biology and Evolution, Molecular Ecology Resources, Methods in Ecology and Evolution, Scientific Reports, Genome Biology and Evolution, Plos Computational Biology, Frontiers in Ecology and Evolution, BMC Ecology and Evolution and Journal of Avian Biology 
*	Recomender for PCI Mathematical and Computational Biology
*	Grant reviews: Czech Science Foundation
